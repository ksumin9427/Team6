//function change(){
   // let luni = document.getElementById("luni").value;
     //       document.getElementById("luni01").style.display="none";
        //    document.getElementById("luni02").style.display="none";
           // document.getElementById("luni03").style.display="none";
           // document.getElementById("luni"+luni).style.display=""; 
 //여기 나오는 코드들은 수강신청 화면에서 선택창을 선택하면 그 선택창에 맞는걸 분류 할려고 만들엇습니다.
//}
function click_ok(){
	document.fr.submit();  //submit 할려고 만들었습니다.
}

