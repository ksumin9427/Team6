package kr.co.koo.izone.user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import kr.co.koo.izone.board.model.BoardVO;
import kr.co.koo.izone.util.JdbcUtil;


public class STUDENT_DAO {
	public static final int LOGIN_SUCCESS = 1;      //로그인 성공
	public static final int LOGIN_FAIL_ID = -1;     //로그인 실패 - 학번 오류
	public static final int LOGIN_FAIL_PW = 0;      //로그인 실패 - 비밀번호 오류

	private static STUDENT_DAO dao = new STUDENT_DAO();
	private DataSource ds;
	
	private STUDENT_DAO() {
		try {
			Context ct = new InitialContext();
			ds = (DataSource) ct.lookup("java:comp/env/jdbc/mysql");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static STUDENT_DAO getInstance() {
		if (dao == null) {
			dao = new STUDENT_DAO();
		}
		return dao;
	}
	
	// 학생 정보 가져오는 메서드
	public STUDENT_VO getMemberInfo(int s_no) {      

		STUDENT_VO user = null;

		String sql = "select * from student where s_no=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, s_no);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				user = new STUDENT_VO();
				user.setS_no(rs.getInt("s_no"));
				user.setS_level(rs.getInt("s_level"));
				user.setS_status(rs.getInt("s_status"));
				user.setMAJOR_no(rs.getInt("MAJOR_no"));
				user.setS_pwd(rs.getString("s_pwd"));
				user.setS_name(rs.getString("s_name"));
				user.setS_jumin(rs.getString("s_jumin"));
				user.setS_email(rs.getString("s_email"));
				user.setS_tel(rs.getString("s_tel"));
				user.setS_birth("s_birth");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn);
			JdbcUtil.close(pstmt);
			JdbcUtil.close(rs);
		}
		return user;
	}
	
		
		// 로그인의 유효성을 검증하는 메서드 선언.
		public int userCheck(int s_no, String s_pwd) {
			// 전달된 정보를 바탕으로 로그인이 유효한지를 판정할 수 있는 JDBC로직 작성

			String sql = "select s_pwd from student where s_no=?";

			int result = 0;

			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;

			try {
				conn = ds.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, s_no);
				rs = pstmt.executeQuery();

				if (rs.next()) {
					String dbpw = rs.getString("s_pwd");
					if (dbpw.equals(s_pwd)) { // 로그인에 성공했을때!
						result = LOGIN_SUCCESS;
					} else { // 비번이 틀렸을때!
						result = LOGIN_FAIL_PW;
					}
				} else { // 아이디가 존재하지 않는경우
					result = LOGIN_FAIL_ID;
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JdbcUtil.close(conn);
				JdbcUtil.close(pstmt);
				JdbcUtil.close(rs);
			}
			return result;
		}
		
		
	
		// 비밀번호 수정을 위한 메서드 선언.
		public boolean changePassword(String s_no, String newPwd){
			
			boolean flag = false;
			
			String sql = "update student set s_pwd = ? where s_no = ?";
			Connection conn=null;
			PreparedStatement pstmt =null;
			
			try {
				conn=ds.getConnection();
				pstmt=conn.prepareStatement(sql);
				
				pstmt.setString(1, newPwd);
				pstmt.setString(2, s_no);
				
				int i = pstmt.executeUpdate();
				
				if(i==1) {
					flag=true;
				}else {
					flag=false;
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JdbcUtil.close(conn);
				JdbcUtil.close(pstmt);
			}
			return flag;
		}
	
		
	
		
		
		//학생정보를 DB에 저장하는 메서드.
		public void write(int s_no, String s_pwd, String s_name, int s_level, String s_birth, String s_email,
				String s_tel, int s_status, int MAJOR_no, String s_jumin) {
			
			String sql = "insert into student values (?,?,?,?,?,?,?,?,?,?)";
			Connection conn = null;
			PreparedStatement pstmt = null;
			
			try {
				conn = ds.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, s_no);
				pstmt.setString(2, s_pwd);
				pstmt.setString(3, s_name);
				pstmt.setInt(4, s_level);
				pstmt.setString(5, s_birth);
				pstmt.setString(6, s_email);
				pstmt.setString(7, s_tel);
				pstmt.setInt(8, s_status);
				pstmt.setInt(9, MAJOR_no);
				pstmt.setString(10, s_jumin);

				int i = pstmt.executeUpdate();
				if(i == 1) {
					System.out.println("정보 등록 성공!");
				} else {
					System.out.println("정보 등록 실패!");
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JdbcUtil.close(conn);
				JdbcUtil.close(pstmt);
			}
			
		}
		
		
		
		//학생정보 목록을 DB로부터 받아올 메서드 선언.
		public List<STUDENT_VO> getStuInfo(){
			
			List<STUDENT_VO> infoList = new ArrayList<>();
			
			String sql = "select * from student order by s_no DESC";
			
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			try {
				conn = ds.getConnection();
				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					STUDENT_VO info = new STUDENT_VO(
							rs.getInt("s_no"), 
							rs.getString("s_pwd"),
							rs.getString("s_name"), 
							rs.getInt("s_level"),
							rs.getString("s_birth"), 	 
							rs.getString("s_email"), 	 
							rs.getString("s_tel"), 	 
							rs.getInt("s_status"),
							rs.getInt("MAJOR_no"),
							rs.getString("s_jumin")	 
							);
					infoList.add(info);
				}
				
				System.out.println("학생 정보 조회 완료!");
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JdbcUtil.close(conn);
				JdbcUtil.close(pstmt);
				JdbcUtil.close(rs);
			}
			
			return infoList;
		}
		
		
		


		//회원정보 수정을 처리하는 메서드 - 학생용
				public boolean updateSTUDENT(STUDENT_VO stu) {
					boolean flag = false;

					Connection conn = null;
					PreparedStatement pstmt = null;

					String sql = "UPDATE student SET s_pwd=?,s_tel=?, s_email=? WHERE s_no=?";

					try {
						conn = ds.getConnection();
						pstmt = conn.prepareStatement(sql);
						pstmt.setString(1, stu.getS_pwd());
						pstmt.setString(2, stu.getS_tel());
						pstmt.setString(3, stu.getS_email());
						pstmt.setInt(4, stu.getS_no());

						int i = pstmt.executeUpdate();

						if(i == 1) {
							flag = true;
						}else {
							flag = false;
						}			
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						JdbcUtil.close(conn);
						JdbcUtil.close(pstmt);
					}

					return flag;
				}
		
				//회원정보 수정을 처리하는 메서드 - 관리자용
				public void updateSTU(int s_no, String s_pwd, String s_name, int s_level, String s_birth, String s_email,
						String s_tel, int s_status, int MAJOR_no, String s_jumin) {
					

					Connection conn = null;
					PreparedStatement pstmt = null;

					String sql = "UPDATE student SET s_pwd=?, s_name=?, s_level=?, s_birth=?, s_email=?, s_tel=?, s_status=?, MAJOR_no=?, s_jumin=? WHERE s_no=?";

					try {
						conn = ds.getConnection();
						pstmt = conn.prepareStatement(sql);
						pstmt.setString(1, s_pwd);
						pstmt.setString(2, s_name);
						pstmt.setInt(3, s_level);
						pstmt.setString(4, s_birth);
						pstmt.setString(5, s_email);
						pstmt.setString(6, s_tel);
						pstmt.setInt(7, s_status);
						pstmt.setInt(8, MAJOR_no);
						pstmt.setString(9, s_jumin);
						pstmt.setInt(10, s_no);

						pstmt.executeUpdate();

						
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						JdbcUtil.close(conn);
						JdbcUtil.close(pstmt);
					}

				}
				
		// 학생의 정보를 삭제할 메서드 선언
				
		public void deleteSTU(int s_no) {
			String sql = "delete from student where s_no = ?";
			Connection conn = null;
			PreparedStatement pstmt = null;
			
			try {
				conn = ds.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, s_no);
				pstmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			}finally {
				JdbcUtil.close(conn);
				JdbcUtil.close(pstmt);
			}
			
		}

				
		
		
		
}
