package kr.co.koo.izone.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class stu_Delete_Service implements stu_Service {

	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		STUDENT_DAO dao = STUDENT_DAO.getInstance();
		String s_no = request.getParameter("s_no");
		dao.deleteSTU(Integer.parseInt(s_no));

	}

}
